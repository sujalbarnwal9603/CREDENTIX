'use server'

import { redirect } from 'next/navigation'

export async function registerUserAction(formData: FormData) {
  const fullName = formData.get('fullName') as string
  const email = formData.get('email') as string
  const password = formData.get('password') as string

  // Hardcode default tenant and role for the free tier
  const tenantSlug = "default-tenant" // Ensure this tenant exists in your backend
  const roleName = "user" // Ensure this role exists in your backend

  if (!fullName || !email || !password) {
    return { success: false, message: "All fields are required." }
  }

  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/api/v1/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ fullName, email, password, tenantSlug, roleName }),
    })

    const data = await response.json()

    if (!response.ok) {
      return { success: false, message: data.message || "Registration failed." }
    }

    // Optionally, you might want to redirect or set a cookie here
    // For now, we'll just return success
    return { success: true, message: "Registration successful! You can now log in." }

  } catch (error) {
    console.error("Error during registration:", error)
    return { success: false, message: "An unexpected error occurred." }
  }
}
